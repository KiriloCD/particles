@tool
extends MultiMeshInstance3D

@export_group("Ресурси")
## Ваша 3D модель (Mesh)
@export var mesh_to_scatter: Mesh:
	set(val):
		mesh_to_scatter = val
		_update_multimesh_resource()

## Текстура для вибору кольорів
@export var color_source_texture: Texture2D

@export_group("Налаштування генерації")
## Кількість копій
@export var instance_count: int = 100
## Зона розкиду
@export var area_size: Vector3 = Vector3(20, 5, 20)
## Мінімальний та максимальний масштаб
@export var scale_range: Vector2 = Vector2(0.8, 1.5)

@export_group("Керування")
@export var button_generate: bool = false:
	set(val):
		if val: generate_scatter()
		button_generate = false

func _update_multimesh_resource():
	# Якщо ресурсу MultiMesh ще немає, створюємо його
	if not multimesh:
		multimesh = MultiMesh.new()
	
	# Важливо: налаштовуємо формат під 3D та використання кольорів
	multimesh.transform_format = MultiMesh.TRANSFORM_3D
	multimesh.use_colors = true
	multimesh.mesh = mesh_to_scatter

func generate_scatter():
	if not mesh_to_scatter:
		push_warning("Спочатку призначте Mesh!")
		return
	
	_update_multimesh_resource()
	
	# Скидаємо count в 0 і назад, щоб оновити буфери
	multimesh.instance_count = 0
	multimesh.instance_count = instance_count

	var rng = RandomNumberGenerator.new()
	rng.randomize()

	var img: Image
	if color_source_texture:
		img = color_source_texture.get_image()

	for i in range(instance_count):
		# 1. Позиція
		var pos = Vector3(
			rng.randf_range(-area_size.x / 2, area_size.x / 2),
			rng.randf_range(-area_size.y / 2, area_size.y / 2),
			rng.randf_range(-area_size.z / 2, area_size.z / 2)
		)
		
		# 2. Трансформація (Поворот + Масштаб)
		var basis = Basis().rotated(Vector3.UP, rng.randf_range(0, TAU))
		var s = rng.randf_range(scale_range.x, scale_range.y)
		basis = basis.scaled(Vector3(s, s, s))
		
		multimesh.set_instance_transform(i, Transform3D(basis, pos))

		# 3. Колір
		if img:
			var px = rng.randi_range(0, img.get_width() - 1)
			var py = rng.randi_range(0, img.get_height() - 1)
			multimesh.set_instance_color(i, img.get_pixel(px, py))
		else:
			# Якщо текстури немає, даємо білий колір
			multimesh.set_instance_color(i, Color.WHITE)

	print("Готово! Розміщено ", instance_count, " екземплярів.")
